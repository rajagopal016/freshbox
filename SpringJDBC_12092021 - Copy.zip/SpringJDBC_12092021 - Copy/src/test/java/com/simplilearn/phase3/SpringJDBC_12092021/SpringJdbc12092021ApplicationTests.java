package com.simplilearn.phase3.SpringJDBC_12092021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbc12092021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
