package com.simplilearn.Quizziz.model;

public class QuizItem {

}
